"""
TODO: Create a type interface for Tangerine Classes.

"""
